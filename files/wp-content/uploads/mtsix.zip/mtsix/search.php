<?php get_header(); ?>

	<div id="main">
		<h2 id="content_top">Posts</h2>
			<div id="content">

	<?php if (have_posts()) : ?>

		<h2 class="pagetitle">Search Results</h2>
		


		<?php while (have_posts()) : the_post(); ?>
				
			<div class="post">
				<h2 id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<!-- <?php the_time('F jS, Y') ?> by <?php the_author() ?> -->
							
				<div class="entry">
					<?php the_content('Read the rest of this entry &raquo;'); ?>
				</div>
							
				<ul class="postmeta">
					<li class="date"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>" class="date"><?php the_time('F jS, Y') ?></a></li>
					<?php edit_post_link('Edit','<li class="all">','</li>'); ?>
					<li class="comments"><?php comments_popup_link('No Comments &raquo;', '1 Comment &raquo;', '% Comments &raquo;'); ?></li>
				</ul>
				<!--
				<?php trackback_rdf(); ?>
				-->
			</div>
	
		<?php endwhile; ?>
	
	<?php else : ?>

		<h2 class="pagetitle">Not Found</h2>
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>

	<?php endif; ?>
		
		</div><!-- div#content -->
		
		<h2 id="content_bottom">Archives and Links</h2>
	</div><!-- div#main -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>