<?php get_header(); ?>

	<div id="main">
		<h2 id="content_top">Posts</h2>
			<div id="content">
				<div class="post">
		
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<h2 id="post-<?php the_ID(); ?>"><?php the_title(); ?></h2>
							<div class="entry">
								<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
							</div>
						</div>
					  <?php endwhile; endif; ?>
					
			<div class="div"><?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?><?php edit_post_link('Edit this entry.', '<p>', '</p>'); ?></div>
		</div><!-- div#content -->
		
		<h2 id="content_bottom">Archives and Links</h2>
	</div><!-- div#main -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>