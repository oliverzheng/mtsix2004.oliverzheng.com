	<hr class="hide" />
	
	<div id="footer">
		<div>
			<p>
			<a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> |
			<a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a> |
			<a href="http://www.wordpress.org">Powered by WordPress</a> |
			<a href="http://www.mtsix.com">Skin by MTsix</a>
			</p>
		</div>
		<!-- <?php echo $wpdb->num_queries; ?> queries. <?php timer_stop(1); ?> seconds. -->
	</div>
	
</div><!-- div#wrapper -->

<!-- Engraving design by Oliver Zheng - http://mtsix.com/ -->

</body>
</html>