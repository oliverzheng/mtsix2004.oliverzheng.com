	<!-- SIDEBAR -->
	
	<div id="sidebar">
		<ul>
			<li class="sidebar"><div class="sidebar_box" id="search_box">
				<?php include (TEMPLATEPATH . '/searchform.php'); ?>
				</div>
			</li>
			<?php /* If this is a category archive */ if (is_category()) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You are currently browsing the archives for the <?php single_cat_title(''); ?> category.</p>
				</div>
			</li>
			
			<?php /* If this is a yearly archive */ } elseif (is_day()) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You are currently browsing the <a href="<?php echo get_settings('siteurl'); ?>"><?php echo bloginfo('name'); ?></a> weblog archives
			for the day <?php the_time('l, F jS, Y'); ?>.</p>
				</div>
			</li>
			
			<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You are currently browsing the <a href="<?php echo get_settings('siteurl'); ?>"><?php echo bloginfo('name'); ?></a> weblog archives
			for <?php the_time('F, Y'); ?>.</p>
				</div>
			</li>

			<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You are currently browsing the <a href="<?php echo get_settings('siteurl'); ?>"><?php echo bloginfo('name'); ?></a> weblog archives
			for the year <?php the_time('Y'); ?>.</p>
				</div>
			</li>
			
			<?php /* If this is a monthly archive */ } elseif (is_search()) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You have searched the <a href="<?php echo get_settings('siteurl'); ?>"><?php echo bloginfo('name'); ?></a> weblog archives
			for <strong>'<?php echo wp_specialchars($s); ?>'</strong>. If you are unable to find anything in these search results, you can try one of these links.</p>
				</div>
			</li>

			<?php /* If this is a monthly archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<p class="description">You are currently browsing the <a href="<?php echo get_settings('siteurl'); ?>"><?php echo bloginfo('name'); ?></a> weblog archives.</p>
				</div>
			</li>

			<?php } ?>
			
			<li class="sidebar"><div class="sidebar_box"><ul>
				<?php wp_list_pages('sort_column=menu_order&title_li=<h2>' . __('Pages') . '</h2>' ); ?>
				</ul></div>
			</li>
			<li class="sidebar"><div class="sidebar_box"><h2><?php _e('Archives'); ?></h2>
				<ul>
				<?php wp_get_archives('type=monthly'); ?>
				</ul></div>
			</li>
			<li class="sidebar"><div class="sidebar_box"><h2><?php _e('Categories'); ?></h2>
				<ul>
				<?php list_cats(0, '', 'name', 'asc', '', 1, 0, 1, 1, 1, 1, 0,'','','','','') ?>
				</ul></div>
			</li>
			<?php /* If this is the frontpage */ if ( is_home() || is_page() ) { ?>				
			
			<?php if (function_exists('wp_theme_switcher')) { ?>
			<li class="sidebar"><div class="sidebar_box">
				<h2 id="theme_switcher"><?php _e('Themes'); ?></h2>
					<?php wp_theme_switcher(); ?>
			</div></li>
			<?php } ?>
			
			
			<li class="sidebar"><div class="sidebar_box"><ul class="links">
			<?php get_links_list('id'); ?>
			</ul></div></li>
				
			<li class="sidebar"><div class="sidebar_box"><h2><?php _e('Meta'); ?></h2>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
					<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>">WordPress</a></li>
					<?php wp_meta(); ?>
				</ul>
				</div>
			</li>
			<?php } ?>
		</ul>
	</div><!-- div#sidebar -->
