<?php get_header(); ?>

	<div id="main">
		<h2 id="content_top">Posts</h2>
			<div id="content">
				<h2 class="center">Error 404 - Not Found</h2>
			</div>
		<h2 id="content_bottom">Archives and Links</h2>
	</div><!-- div#main -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>